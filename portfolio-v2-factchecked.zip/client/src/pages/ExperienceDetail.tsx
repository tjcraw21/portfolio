import { useEffect, useRef } from "react";
import { ArrowLeft, ArrowUpRight, MapPin } from "lucide-react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

// ─── All experience data ───────────────────────────────────────────────────

const experienceData: Record<string, ExperienceEntry> = {
  "freedom-mobile": {
    slug: "freedom-mobile",
    company: "Freedom Mobile",
    role: "Social Media Intern",
    team: "Advertising & Social",
    period: "Sept 2025 — Present",
    location: "Toronto, ON",
    type: "Internship",
    current: true,
    url: "https://www.freedommobile.ca",
    image: "/manus-storage/freedom-mobile-logo_f8b6e924.png",
    tagline: "Driving Canada's challenger telecom brand across every major social platform.",
    challenge:
      "Freedom Mobile operates in a crowded Canadian telecom market dominated by Rogers, Bell, and Telus. As an intern on the Advertising & Social team, I joined a fast-moving environment where campaign accuracy, cross-functional coordination, and execution discipline were non-negotiable — especially across a $20M+ marketing ecosystem.",
    strategy:
      "I support campaign execution across Meta, TikTok, X, and LinkedIn — coordinating asset trafficking, monitoring launch timelines, and maintaining rollout accuracy across 5+ concurrent activations. I contribute to go-to-market planning for integrated promotions and develop paid social mockups via Meta Creative Hub, collaborating with agency partners on targeting alignment and launch prep.",
    results: [
      { label: "Campaign Views", value: "2.78M+", description: "Driven through creative sequencing, format testing, and paid boosting coordination during a seasonal activation" },
      { label: "Engagement Growth", value: "6×", description: "Year-over-year engagement growth during a time-sensitive seasonal campaign" },
      { label: "Interaction Metrics", value: "+22% QoQ", description: "Quarter-over-quarter increase in interaction metrics via reporting dashboard insights" },
      { label: "Concurrent Launches", value: "5+", description: "Campaign rollout timelines monitored simultaneously across platforms" },
    ],
    highlights: [
      "Support digital campaign execution across Meta, TikTok, X, and LinkedIn — coordinating asset trafficking and launch readiness with cross-functional stakeholders.",
      "Monitor campaign rollout timelines and content delivery across 5+ concurrent launches, maintaining execution accuracy in a fast-paced retail marketing environment.",
      "Contribute to go-to-market planning for integrated promotions spanning social, broadcast, and web.",
      "Develop paid social mockups using Meta Creative Hub and collaborate with paid media agency partners on targeting alignment and launch preparation.",
      "Build and maintain Excel-based reporting dashboards and post-campaign insight decks summarizing engagement trends and optimization opportunities.",
      "Drove 2.78M+ campaign views and 6× engagement growth by sequencing launches, testing creative formats, and coordinating paid boosting support during a time-sensitive seasonal activation.",
    ],
    skills: ["Campaign Execution", "Asset Trafficking", "Meta Creative Hub", "Performance Reporting", "GTM Planning", "Agency Coordination", "Excel Dashboards"],
  },
  "crwfrd-digital": {
    slug: "crwfrd-digital",
    company: "CRWFRD Digital",
    role: "Founder & Digital Marketing Operations Lead",
    team: "Independent",
    period: "2024 — Present",
    location: "Toronto, ON",
    type: "Freelance",
    current: true,
    url: null,
    image: null,
    tagline: "A boutique growth agency built to help local service businesses acquire customers through targeted Meta Ads.",
    challenge:
      "Local service businesses — barbershops, chiropractors, physio clinics — are leaving serious revenue on the table because they lack the time, knowledge, or budget to run effective paid media. Most agencies are too expensive, too generic, or too hands-off to actually move the needle for smaller operators.",
    strategy:
      "I built CRWFRD Digital to fill that gap. My model is end-to-end and operator-focused: I handle research, audience targeting, creative direction, campaign builds, landing page optimization, and reporting. I developed reusable SOPs and campaign frameworks that let me deliver agency-quality results with boutique responsiveness — starting with a barber client in Brampton and building toward a chiro/physio niche focus.",
    results: [
      { label: "Client #1", value: "Viibe Hair Studio", description: "Full Meta Ads campaign built for Christopher Carandang's barbershop in Brampton" },
      { label: "Niche", value: "Chiro / Physio", description: "Targeting local service businesses with high LTV and recurring appointment cycles" },
      { label: "Deliverables", value: "End-to-end", description: "Research, creative, campaign build, landing page, and performance SOPs" },
      { label: "Approach", value: "Systems-first", description: "Reusable frameworks that scale across clients without sacrificing quality" },
    ],
    highlights: [
      "Operate a boutique lead generation and growth agency focused on running Meta Ads for local service businesses.",
      "Build and manage end-to-end Meta Ads campaigns — from audience strategy and creative direction to landing page optimization and reporting.",
      "Develop tailored SOPs, content frameworks, and messaging strategies that give early-stage brands a sustainable foundation for digital growth.",
      "Research and select high-value niches with recurring revenue potential, currently focused on chiropractic and physiotherapy clinics.",
    ],
    skills: ["Meta Ads", "Lead Generation", "Content Strategy", "Brand Messaging", "Organic Growth", "Landing Page Optimization", "SOPs"],
  },
  "agent-sauce": {
    slug: "agent-sauce",
    company: "Agent Sauce",
    role: "Marketing Intern",
    team: "Internship",
    period: "Mar — Jun 2023",
    location: "Remote",
    type: "Internship",
    current: false,
    url: "https://agentsauce.com",
    image: "/agent-sauce.png",
    tagline: "SEO-driven copy and creative content for a real estate SaaS brand.",
    challenge:
      "Agent Sauce had a compelling product for real estate agents but a content presence that wasn't pulling its weight. The landing pages weren't converting, organic search visibility was thin, and the brand voice hadn't found a tone that resonated with busy agents who are skeptical of SaaS promises.",
    strategy:
      "I developed a keyword-informed content strategy built around high-intent searches from real estate agents. I rewrote core landing pages to sharpen the value proposition, created an editorial calendar to sustain organic traffic growth, and developed a brand voice framework that positioned Agent Sauce as a practical, agent-first tool — not another overcomplicated SaaS product.",
    results: [
      { label: "Deliverable", value: "SEO Strategy", description: "Keyword research and intent mapping across core site pages and blog" },
      { label: "Copy", value: "Landing Pages", description: "Rewrote core pages to tighten value proposition and improve conversion clarity" },
      { label: "Content", value: "Editorial Plan", description: "Built a sustained content calendar targeting high-intent real estate agent queries" },
      { label: "Brand Voice", value: "Framework", description: "Agent-forward tone that made technical SaaS features feel approachable and practical" },
    ],
    highlights: [
      "Developed keyword-rich copy for landing pages and product features, improving organic search visibility for a real estate SaaS platform.",
      "Created a content strategy covering blog topics, SEO intent mapping, and editorial calendar to support sustained organic traffic growth.",
      "Produced creative brand content that aligned the technical product with a relatable, agent-forward voice.",
      "Delivered a keyword research framework and intent map to guide ongoing content production.",
    ],
    skills: ["SEO Copywriting", "Content Strategy", "SaaS Marketing", "Keyword Research", "Editorial Planning", "Brand Voice"],
  },
};

// ─── Types ─────────────────────────────────────────────────────────────────

interface ExperienceEntry {
  slug: string;
  company: string;
  role: string;
  team: string;
  period: string;
  location: string;
  type: string;
  current: boolean;
  url: string | null;
  image: string | null;
  tagline: string;
  challenge: string;
  strategy: string;
  results: { label: string; value: string; description: string }[];
  highlights: string[];
  skills: string[];
}

// ─── Component ─────────────────────────────────────────────────────────────

export default function ExperienceDetail({ slug }: { slug: string }) {
  const [, navigate] = useLocation();
  const exp = experienceData[slug];
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    setTimeout(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    }, 100);
  }, []);

  if (!exp) {
    navigate("/");
    return null;
  }

  return (
    <div className="grain-overlay min-h-screen bg-[#0F0F0D]">
      <Navbar />

      {/* Hero banner */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        {exp.image && (
          <>
            <div
              className="absolute inset-0 bg-cover bg-center opacity-15"
              style={{ backgroundImage: `url(${exp.image})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#0F0F0D]/80 via-[#0F0F0D]/60 to-[#0F0F0D]" />
          </>
        )}

        <div className="relative z-10 max-w-[1100px] mx-auto px-6 lg:px-12">
          {/* Back */}
          <button
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 font-mono text-[10px] text-[#4A4A48] hover:text-[#A8A8A0] tracking-widest uppercase transition-colors mb-12 group"
          >
            <ArrowLeft size={12} className="group-hover:-translate-x-1 transition-transform duration-300" />
            Back to Home
          </button>

          <div
            ref={heroRef}
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.7s ease, transform 0.7s ease" }}
          >
            {/* Meta */}
            <div className="flex flex-wrap items-center gap-3 mb-6">
              {exp.current && (
                <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] border border-[#A8A8A0]/25 px-2 py-0.5 tracking-widest uppercase">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A8A8A0] dot-pulse" />
                  Current
                </span>
              )}
              <span className="font-mono text-[10px] text-[#4A4A48] border border-white/6 px-2 py-0.5 tracking-widest uppercase">
                {exp.type}
              </span>
              <span className="flex items-center gap-1 font-mono text-[10px] text-[#3A3A38]">
                <MapPin size={10} />
                {exp.location}
              </span>
              <span className="font-mono text-[10px] text-[#3A3A38]">{exp.period}</span>
            </div>

            <h1 className="font-display text-5xl lg:text-7xl font-light text-[#F0EDE8] leading-[1.05] mb-3">
              {exp.company}
            </h1>
            <div className="flex items-center gap-2 mb-6">
              <p className="font-body text-base text-[#7A7A75]">{exp.role}</p>
              {exp.url && (
                <a href={exp.url} target="_blank" rel="noopener noreferrer" className="text-[#3A3A38] hover:text-[#A8A8A0] transition-colors">
                  <ArrowUpRight size={14} />
                </a>
              )}
            </div>
            <p className="font-display text-xl lg:text-2xl font-light text-[#9A9690] italic max-w-2xl leading-relaxed">
              "{exp.tagline}"
            </p>
          </div>
        </div>
      </section>

      {/* Divider */}
      <div className="max-w-[1100px] mx-auto px-6 lg:px-12">
        <div className="hairline" />
      </div>

      {/* C/S/R Body */}
      <section className="py-20">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-12 space-y-20">

          {/* Challenge */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Challenge</span>
            </div>
            <div className="lg:col-span-9">
              <p className="font-body text-base text-[#7A7A75] leading-relaxed">{exp.challenge}</p>
            </div>
          </div>

          <div className="hairline" />

          {/* Strategy */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Strategy</span>
            </div>
            <div className="lg:col-span-9">
              <p className="font-body text-base text-[#7A7A75] leading-relaxed mb-8">{exp.strategy}</p>
              <div className="space-y-3">
                {exp.highlights.map((h, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <span className="w-1 h-1 rounded-full bg-[#A8A8A0]/40 flex-shrink-0 mt-2.5" />
                    <p className="font-body text-sm text-[#5A5A55] leading-relaxed">{h}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="hairline" />

          {/* Results */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Results</span>
            </div>
            <div className="lg:col-span-9">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/5">
                {exp.results.map((r, i) => (
                  <div key={i} className="bg-[#0F0F0D] p-6 hover:bg-[#141412] transition-colors duration-300">
                    <span className="font-mono text-[10px] text-[#3A3A38] tracking-widest uppercase block mb-2">{r.label}</span>
                    <p className="font-display text-2xl lg:text-3xl font-light text-[#F0EDE8] mb-2">{r.value}</p>
                    <p className="font-body text-xs text-[#4A4A48] leading-relaxed">{r.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="hairline" />

          {/* Skills */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Skills Used</span>
            </div>
            <div className="lg:col-span-9 flex flex-wrap gap-2">
              {exp.skills.map((s) => (
                <span key={s} className="font-mono text-[10px] text-[#5A5A55] border border-white/8 px-3 py-1.5 tracking-wide uppercase">
                  {s}
                </span>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* Nav to other experiences */}
      <section className="border-t border-white/6 py-16">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-12">
          <span className="font-mono text-[10px] text-[#3A3A38] tracking-widest uppercase block mb-8">More Experience</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {Object.values(experienceData)
              .filter((e) => e.slug !== slug)
              .map((e) => (
                <button
                  key={e.slug}
                  onClick={() => navigate(`/experience/${e.slug}`)}
                  className="group text-left p-5 border border-white/6 hover:border-[#A8A8A0]/20 hover:bg-white/2 transition-all duration-300"
                >
                  <p className="font-display text-lg font-light text-[#F0EDE8] group-hover:text-white transition-colors mb-1">{e.company}</p>
                  <p className="font-body text-xs text-[#4A4A48] mb-3">{e.role}</p>
                  <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] group-hover:gap-2.5 transition-all duration-300">
                    View <ArrowUpRight size={10} />
                  </span>
                </button>
              ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
