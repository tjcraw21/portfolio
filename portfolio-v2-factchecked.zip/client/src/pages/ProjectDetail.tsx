import { useEffect, useRef } from "react";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const projectData: Record<string, ProjectEntry> = {
  "mothers-grief-journey": {
    slug: "mothers-grief-journey",
    name: "Mothers Grief Journey",
    year: "2025",
    category: "Brand Strategy",
    url: "https://mothersgriefjourney.net",
    image: "/mothers-grief.png",
    tagline: "A brand built to turn grief into community, and stories into healing.",
    challenge:
      "Mothers Grief Journey needed a digital presence that could hold space for profound loss while still functioning as a platform — one that would attract readers, build community, and support book sales. The risk was a brand that felt either too clinical or too raw; neither would build the trust required to invite someone into their grief.",
    strategy:
      "I developed a full brand strategy rooted in emotional resonance and editorial restraint. The brand voice was built around 'healing through storytelling' — a frame that gave the platform both a purpose and a content model. I mapped out content pillars that balanced personal narrative, community connection, and book promotion without letting any one of them dominate. The visual and copy direction leaned into quiet dignity: dark, considered, human.",
    results: [
      { label: "Brand Voice", value: "Developed", description: "Full voice and tone framework built around healing, dignity, and shared experience" },
      { label: "Content Pillars", value: "4 defined", description: "Narrative, community, resource, and promotional — each with its own editorial role" },
      { label: "Audience", value: "Framework", description: "Audience segmentation and engagement strategy for bereaved mothers and grief support communities" },
      { label: "Platform", value: "Live", description: "Brand strategy translated into a functioning digital presence at mothersgriefjourney.net" },
    ],
    highlights: [
      "Developed brand voice and tone framework rooted in emotional resonance, editorial restraint, and dignity.",
      "Created four content pillars balancing narrative storytelling, community engagement, and book promotion.",
      "Built an audience development strategy targeting bereaved mothers, grief support communities, and literary readers.",
      "Translated strategy into a cohesive digital presence with clear messaging hierarchy and content direction.",
    ],
    skills: ["Brand Identity", "Content Strategy", "Audience Development", "Brand Voice", "Editorial Direction"],
  },
  "lumiorb": {
    slug: "lumiorb",
    name: "LumiOrb",
    year: "2024",
    category: "Growth Strategy",
    url: null,
    image: "/lumiorb.png",
    tagline: "A celestial DTC product launched and grown entirely through short-form content.",
    challenge:
      "LumiOrb was entering a crowded DTC gift market with no organic audience, no paid budget, and no distribution. The product had genuine visual appeal — a galaxy crystal lamp — but needed a growth strategy that could generate awareness and sales without traditional advertising spend.",
    strategy:
      "I designed a short-form content-first growth strategy built around the product's strongest asset: how it looks. The organic social playbook led with visual hooks — unboxing moments, room ambiance shots, and the 'galaxy reveal' — to drive shareability on TikTok and Instagram Reels. I layered in an influencer seeding approach targeting home decor and ambient lifestyle creators in micro-tier, and set performance benchmarks tied to views, saves, and conversion to first purchase.",
    results: [
      { label: "Content", value: "Playbook", description: "Full short-form content strategy built around visual hooks and shareable moments" },
      { label: "Distribution", value: "Influencer seeding", description: "Micro-tier creator strategy targeting home decor and ambient lifestyle audiences" },
      { label: "Channels", value: "TikTok + Reels", description: "Platform strategy optimized for algorithm-driven organic discovery" },
      { label: "Benchmarks", value: "Defined", description: "Performance metrics tied to views, saves, link clicks, and first purchase conversion" },
    ],
    highlights: [
      "Designed full organic social playbook built around the product's visual identity and the 'galaxy reveal' hook.",
      "Developed influencer seeding strategy targeting micro-tier home decor and ambient lifestyle creators.",
      "Optimized content approach for TikTok and Instagram Reels algorithm discovery with hook-first formats.",
      "Set clear performance benchmarks across awareness, engagement, and conversion stages.",
    ],
    skills: ["DTC Growth", "Short-Form Content", "Organic Social", "Influencer Strategy", "Content Playbook"],
  },
  "shufflemate": {
    slug: "shufflemate",
    name: "Shufflemate",
    year: "2024",
    category: "Content Production",
    url: "https://shufflemate.com",
    image: "/shufflemate.png",
    tagline: "Game night's new MVP — positioned through lifestyle creative and sharp ad copy.",
    challenge:
      "Shufflemate was a well-made card shuffler entering a market that barely knew it needed one. The challenge was dual: make the product feel desirable beyond its utility, and produce content that could drive both organic reach and paid performance across social.",
    strategy:
      "I led end-to-end content production with a lifestyle-first creative direction. Rather than leading with the product's mechanical function, I positioned Shufflemate around the game night experience — the laughter, the snacks, the ritual. The ad copy leaned into rhythm and energy ('Shuffle faster, play longer, laugh louder'), and the photography direction built warmth and occasion into every frame. Content was designed to work in feed, story, and ad formats simultaneously.",
    results: [
      { label: "Ad Copy", value: "Campaign ready", description: "Headline and body copy developed for feed ads, story formats, and product pages" },
      { label: "Direction", value: "Lifestyle-first", description: "Photography and content direction rooted in game night occasion rather than product function" },
      { label: "Formats", value: "Multi-format", description: "Content built to perform across organic feed, stories, and paid social placements" },
      { label: "Positioning", value: "MVP framing", description: "'Game night's new MVP' — a positioning line that gave the product cultural relevance" },
    ],
    highlights: [
      "Led creative direction for lifestyle photography positioning Shufflemate within the game night occasion.",
      "Wrote ad copy and campaign headlines designed for high-energy, impulse-driven social formats.",
      "Developed content architecture covering feed posts, story formats, and paid ad placements.",
      "Positioned product around the game night experience — emotion over function.",
    ],
    skills: ["Content Production", "Ad Copy", "Lifestyle Creative", "Creative Direction", "Social Content"],
  },
};

interface ProjectEntry {
  slug: string;
  name: string;
  year: string;
  category: string;
  url: string | null;
  image: string;
  tagline: string;
  challenge: string;
  strategy: string;
  results: { label: string; value: string; description: string }[];
  highlights: string[];
  skills: string[];
}

export default function ProjectDetail({ slug }: { slug: string }) {
  const [, navigate] = useLocation();
  const project = projectData[slug];
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const el = heroRef.current;
    if (!el) return;
    setTimeout(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    }, 100);
  }, []);

  if (!project) {
    navigate("/");
    return null;
  }

  return (
    <div className="grain-overlay min-h-screen bg-[#0F0F0D]">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-12"
          style={{ backgroundImage: `url(${project.image})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F0F0D]/85 via-[#0F0F0D]/50 to-[#0F0F0D]" />

        <div className="relative z-10 max-w-[1100px] mx-auto px-6 lg:px-12">
          <button
            onClick={() => navigate("/")}
            className="inline-flex items-center gap-2 font-mono text-[10px] text-[#4A4A48] hover:text-[#A8A8A0] tracking-widest uppercase transition-colors mb-12 group"
          >
            <ArrowLeft size={12} className="group-hover:-translate-x-1 transition-transform duration-300" />
            Back to Home
          </button>

          <div
            ref={heroRef}
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.7s ease, transform 0.7s ease" }}
          >
            <div className="flex flex-wrap items-center gap-3 mb-6">
              <span className="font-mono text-[10px] text-[#4A4A48] border border-white/6 px-2 py-0.5 tracking-widest uppercase">
                {project.category}
              </span>
              <span className="font-mono text-[10px] text-[#3A3A38]">{project.year}</span>
            </div>

            <h1 className="font-display text-5xl lg:text-7xl font-light text-[#F0EDE8] leading-[1.05] mb-3">
              {project.name}
            </h1>
            <div className="flex items-center gap-2 mb-6">
              {project.url && (
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] hover:text-[#C8C8C2] tracking-widest uppercase transition-colors"
                >
                  Visit Site <ArrowUpRight size={10} />
                </a>
              )}
            </div>
            <p className="font-display text-xl lg:text-2xl font-light text-[#9A9690] italic max-w-2xl leading-relaxed">
              "{project.tagline}"
            </p>
          </div>
        </div>
      </section>

      {/* Hero image full-width */}
      <div className="max-w-[1100px] mx-auto px-6 lg:px-12 mb-0">
        <div className="hairline" />
      </div>
      <div className="max-w-[1100px] mx-auto px-6 lg:px-12 py-12">
        <div className="overflow-hidden aspect-[16/7] bg-[#1A1A18]">
          <img
            src={project.image}
            alt={project.name}
            className="w-full h-full object-cover opacity-80"
          />
        </div>
      </div>
      <div className="max-w-[1100px] mx-auto px-6 lg:px-12">
        <div className="hairline" />
      </div>

      {/* C/S/R */}
      <section className="py-20">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-12 space-y-20">

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Challenge</span>
            </div>
            <div className="lg:col-span-9">
              <p className="font-body text-base text-[#7A7A75] leading-relaxed">{project.challenge}</p>
            </div>
          </div>

          <div className="hairline" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Strategy</span>
            </div>
            <div className="lg:col-span-9">
              <p className="font-body text-base text-[#7A7A75] leading-relaxed mb-8">{project.strategy}</p>
              <div className="space-y-3">
                {project.highlights.map((h, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <span className="w-1 h-1 rounded-full bg-[#A8A8A0]/40 flex-shrink-0 mt-2.5" />
                    <p className="font-body text-sm text-[#5A5A55] leading-relaxed">{h}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="hairline" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Results</span>
            </div>
            <div className="lg:col-span-9">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-white/5">
                {project.results.map((r, i) => (
                  <div key={i} className="bg-[#0F0F0D] p-6 hover:bg-[#141412] transition-colors duration-300">
                    <span className="font-mono text-[10px] text-[#3A3A38] tracking-widest uppercase block mb-2">{r.label}</span>
                    <p className="font-display text-2xl lg:text-3xl font-light text-[#F0EDE8] mb-2">{r.value}</p>
                    <p className="font-body text-xs text-[#4A4A48] leading-relaxed">{r.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="hairline" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-3">
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block pt-1">Skills Used</span>
            </div>
            <div className="lg:col-span-9 flex flex-wrap gap-2">
              {project.skills.map((s) => (
                <span key={s} className="font-mono text-[10px] text-[#5A5A55] border border-white/8 px-3 py-1.5 tracking-wide uppercase">
                  {s}
                </span>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* More projects */}
      <section className="border-t border-white/6 py-16">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-12">
          <span className="font-mono text-[10px] text-[#3A3A38] tracking-widest uppercase block mb-8">More Projects</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {Object.values(projectData)
              .filter((p) => p.slug !== slug)
              .map((p) => (
                <button
                  key={p.slug}
                  onClick={() => navigate(`/work/${p.slug}`)}
                  className="group text-left p-5 border border-white/6 hover:border-[#A8A8A0]/20 hover:bg-white/2 transition-all duration-300"
                >
                  <div className="overflow-hidden aspect-[16/7] mb-4 bg-[#1A1A18]">
                    <img src={p.image} alt={p.name} className="w-full h-full object-cover opacity-40 group-hover:opacity-65 transition-opacity duration-500 group-hover:scale-105 transform transition-transform" />
                  </div>
                  <p className="font-display text-lg font-light text-[#F0EDE8] group-hover:text-white transition-colors mb-1">{p.name}</p>
                  <p className="font-body text-xs text-[#4A4A48] mb-3">{p.category} · {p.year}</p>
                  <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] group-hover:gap-2.5 transition-all duration-300">
                    View Project <ArrowUpRight size={10} />
                  </span>
                </button>
              ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
