import { useRef, useEffect } from "react";

const interests = [
  "Brand Psychology",
  "Weightlifting",
  "Travelling",
  "Cooking",
  "Marketing Trends",
  "Self-Improvement",
];

const capabilities = [
  { label: "Strategy", items: ["Brand Strategy", "Go-to-Market", "Content Strategy", "Audience Development"] },
  { label: "Execution", items: ["Organic Social", "Campaign Management", "Influencer Marketing", "SEO Copywriting"] },
  { label: "Paid Media", items: ["Meta Ads", "Lead Generation", "Landing Page Optimization", "A/B Testing"] },
];

export default function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const revealEls = entry.target.querySelectorAll(".reveal-item");
            revealEls.forEach((child, i) => {
              setTimeout(() => {
                (child as HTMLElement).style.opacity = "1";
                (child as HTMLElement).style.transform = "translateY(0)";
              }, i * 100);
            });
          }
        });
      },
      { threshold: 0.05 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-24 lg:py-32 bg-[#0F0F0D]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div
          className="reveal-item mb-16"
          style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
        >
          <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block mb-3">
            About
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-light text-[#F0EDE8]">
            The Person Behind the Work
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          <div className="lg:col-span-5">
            <div
              className="reveal-item"
              style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
            >
              <p className="font-display text-2xl lg:text-3xl font-light text-[#F0EDE8] leading-relaxed italic mb-8">
                "Driven by curiosity and a genuine love of learning, I thrive as a self-starter — taking initiative, solving problems, and pushing for better."
              </p>
              <div className="hairline mb-8" />
              <div>
                <span className="font-mono text-[10px] text-[#4A4A48] tracking-widest uppercase block mb-4">
                  Interests
                </span>
                <div className="flex flex-wrap gap-2">
                  {interests.map((interest) => (
                    <span
                      key={interest}
                      className="font-body text-sm text-[#5A5A55] border border-white/6 px-3 py-1.5 hover:border-[#A8A8A0]/20 hover:text-[#7A7A75] transition-all duration-300"
                    >
                      {interest}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div
              className="reveal-item mb-8"
              style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
            >
              <p className="font-body text-base text-[#6A6A65] leading-relaxed mb-4">
                I'm a Toronto-based marketer who works at the intersection of brand, content, and performance. By day, I run social strategy and campaign execution at Freedom Mobile — coordinating agency partners, driving influencer activations, and making sure campaigns cut through the noise.
              </p>
              <p className="font-body text-base text-[#6A6A65] leading-relaxed">
                By night, I build CRWFRD Digital — a boutique growth agency where I run Meta Ads for local service businesses, helping them generate qualified leads without a bloated marketing budget. I care deeply about doing the work well, understanding why things work, and building things that last.
              </p>
            </div>

            <div className="hairline mb-8" />

            <div
              className="reveal-item grid grid-cols-1 sm:grid-cols-3 gap-8"
              style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
            >
              {capabilities.map((cap) => (
                <div key={cap.label}>
                  <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block mb-3">
                    {cap.label}
                  </span>
                  <ul className="space-y-1.5">
                    {cap.items.map((item) => (
                      <li key={item} className="font-body text-sm text-[#5A5A55]">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
