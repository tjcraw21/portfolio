import { useEffect, useRef } from "react";
import { ArrowDown } from "lucide-react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663574538158/DE9MRw77NHewnbKVQTjPK6/hero-bg-cWjtRRUdpB5pMEScETCVn6.webp";

export default function HeroSection() {
  const wordsRef = useRef<(HTMLSpanElement | null)[]>([]);
  const badgeRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const metaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Badge first
    if (badgeRef.current) {
      setTimeout(() => {
        badgeRef.current!.style.opacity = "1";
        badgeRef.current!.style.transform = "translateY(0)";
      }, 150);
    }
    // Words staggered
    wordsRef.current.forEach((word, i) => {
      if (!word) return;
      setTimeout(() => {
        word.style.opacity = "1";
        word.style.transform = "translateY(0)";
      }, 350 + i * 55);
    });
    // CTA
    if (ctaRef.current) {
      setTimeout(() => {
        ctaRef.current!.style.opacity = "1";
        ctaRef.current!.style.transform = "translateY(0)";
      }, 1300);
    }
    // Meta sidebar
    if (metaRef.current) {
      setTimeout(() => {
        metaRef.current!.style.opacity = "1";
        metaRef.current!.style.transform = "translateY(0)";
      }, 1000);
    }
  }, []);

  const headline = "I help brands grow through strategy, storytelling, and performance.";
  const words = headline.split(" ");

  const scrollToExperience = () => {
    document.querySelector("#experience")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      className="relative min-h-screen flex flex-col justify-end pb-24 overflow-hidden"
      style={{
        backgroundImage: `url(${HERO_BG})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      {/* Layered dark gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0F0F0D]/70 via-[#0F0F0D]/30 to-[#0F0F0D]" />
      <div className="absolute inset-0 bg-gradient-to-r from-[#0F0F0D]/50 to-transparent" />

      <div className="relative z-10 max-w-[1400px] mx-auto px-6 lg:px-12 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-8">
            {/* Status badge */}
            <div
              ref={badgeRef}
              className="inline-flex items-center gap-2.5 mb-10 bg-white/4 border border-white/8 px-3 py-1.5 backdrop-blur-sm"
              style={{ opacity: 0, transform: "translateY(16px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#A8A8A0] dot-pulse" />
              <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase">
                Brand &amp; Advertising · Freedom Mobile · Toronto
              </span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl xl:text-[5.5rem] font-light leading-[1.05] text-[#F0EDE8] mb-10">
              {words.map((word, i) => (
                <span
                  key={i}
                  ref={(el) => { wordsRef.current[i] = el; }}
                  className="inline-block mr-[0.22em] last:mr-0"
                  style={{
                    opacity: 0,
                    transform: "translateY(24px)",
                    transition: "opacity 0.55s cubic-bezier(0.25, 0.46, 0.45, 0.94), transform 0.55s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
                  }}
                >
                  {word}
                </span>
              ))}
            </h1>

            <div
              ref={ctaRef}
              className="flex flex-col sm:flex-row items-start sm:items-center gap-4"
              style={{ opacity: 0, transform: "translateY(16px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
            >
              <button
                onClick={scrollToExperience}
                className="group inline-flex items-center gap-3 font-body text-sm font-medium px-6 py-3 bg-[#F0EDE8] text-[#0F0F0D] hover:bg-white transition-colors duration-300"
              >
                View My Work
                <ArrowDown size={14} className="group-hover:translate-y-1 transition-transform duration-300" />
              </button>
              <a
                href="mailto:tristan.crawford@torontomu.ca"
                className="font-body text-sm font-medium text-[#A8A8A0] hover:text-[#F0EDE8] transition-colors link-underline"
              >
                tristan.crawford@torontomu.ca
              </a>
            </div>
          </div>

          {/* Right side metadata */}
          <div
            ref={metaRef}
            className="lg:col-span-4 hidden lg:flex flex-col gap-4 pb-2"
            style={{ opacity: 0, transform: "translateY(16px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
          >
            <p className="font-body text-sm text-[#5A5A55] leading-relaxed">
              Digital marketer from Toronto crafting campaigns that resonate — across content, brand strategy, and performance channels.
            </p>
            <div className="hairline" />
            <div className="flex flex-wrap gap-2">
              {["Brand Strategy", "Organic Social", "Content Production", "SEO Copywriting", "Growth Marketing"].map((tag) => (
                <span
                  key={tag}
                  className="font-mono text-[10px] text-[#4A4A48] border border-white/8 px-2 py-1 tracking-wide uppercase hover:border-[#A8A8A0]/30 hover:text-[#7A7A75] transition-colors duration-300"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 right-12 hidden lg:flex flex-col items-center gap-2 opacity-30">
        <span className="font-mono text-[10px] text-[#F0EDE8] tracking-widest uppercase rotate-90 origin-center translate-x-4">Scroll</span>
        <div className="w-px h-12 bg-[#F0EDE8]/30" />
      </div>
    </section>
  );
}
