export default function MarqueeTicker() {
  const items = [
    "Driving social growth @ Freedom Mobile",
    "Brand Strategy",
    "Organic Social Campaigns",
    "Content Production",
    "Influencer Marketing",
    "SEO Copywriting",
    "Performance Marketing",
    "Meta Ads",
    "Toronto, ON",
  ];

  const repeated = [...items, ...items, ...items];

  return (
    <div className="bg-[#0D0D0B] border-y border-white/5 py-3 overflow-hidden">
      <div className="ticker-track">
        {repeated.map((item, i) => (
          <span key={i} className="inline-flex items-center gap-3 px-6 flex-shrink-0">
            <span className="w-1 h-1 rounded-full bg-[#A8A8A0]/50 flex-shrink-0" />
            <span className="font-mono text-[10px] text-[#3A3A38] tracking-widest uppercase whitespace-nowrap">
              {item}
            </span>
          </span>
        ))}
      </div>
    </div>
  );
}
