import { useRef, useEffect } from "react";
import { Mail, Linkedin } from "lucide-react";

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const revealEls = entry.target.querySelectorAll(".reveal-contact");
            revealEls.forEach((child, i) => {
              setTimeout(() => {
                (child as HTMLElement).style.opacity = "1";
                (child as HTMLElement).style.transform = "translateY(0)";
              }, i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="contact" ref={sectionRef} className="py-24 lg:py-40 bg-[#0D0D0B]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div className="max-w-3xl">
          <div
            className="reveal-contact mb-4"
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
          >
            <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase">
              Contact
            </span>
          </div>

          <div
            className="reveal-contact mb-8"
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
          >
            <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-light text-[#F0EDE8] leading-[1.1]">
              Let's build something worth talking about.
            </h2>
          </div>

          <div
            className="reveal-contact mb-12"
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
          >
            <p className="font-body text-base text-[#5A5A55] leading-relaxed max-w-xl">
              Whether you have a brand to grow, a campaign to launch, or an idea worth exploring — I'd love to hear from you. Always open to meaningful conversations.
            </p>
          </div>

          <div
            className="reveal-contact flex flex-col sm:flex-row items-start gap-4"
            style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
          >
            <a
              href="mailto:tristan.crawford@torontomu.ca"
              className="group inline-flex items-center gap-3 font-body text-sm font-medium px-6 py-3.5 bg-[#F0EDE8] text-[#0F0F0D] hover:bg-white transition-colors duration-300"
            >
              <Mail size={15} />
              Send an Email
            </a>
            <a
              href="https://linkedin.com/in/tristancrawford"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-3 font-body text-sm font-medium px-6 py-3.5 border border-white/10 text-[#9A9690] hover:border-[#A8A8A0]/30 hover:text-[#C8C8C2] transition-all duration-300"
            >
              <Linkedin size={15} />
              Connect on LinkedIn
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
