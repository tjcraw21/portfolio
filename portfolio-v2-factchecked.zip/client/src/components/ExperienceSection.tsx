import { useRef, useEffect } from "react";
import { MapPin, ArrowUpRight } from "lucide-react";
import { useLocation } from "wouter";

const FREEDOM_IMG = "/manus-storage/freedom-mobile-logo_f8b6e924.png";

const experiences = [
  {
    slug: "freedom-mobile",
    company: "Freedom Mobile",
    role: "Social Media Intern",
    team: "Advertising & Social",
    period: "Sept 2025 — Present",
    location: "Toronto, ON",
    type: "Internship",
    current: true,
    url: "https://www.freedommobile.ca",
    summary: "Supporting campaign execution and paid social operations for Canada's challenger telecom brand across Meta, TikTok, X, and LinkedIn.",
    skills: ["Organic Social", "Campaign Management", "Influencer Marketing", "GTM Planning"],
  },
  {
    slug: "crwfrd-digital",
    company: "CRWFRD Digital",
    role: "Founder & Digital Marketing Operations Lead",
    team: "Independent Agency",
    period: "2024 — Present",
    location: "Toronto, ON",
    type: "Freelance",
    current: true,
    url: null,
    summary: "Boutique growth agency running end-to-end Meta Ads campaigns for local service businesses — from audience strategy to landing page optimization.",
    skills: ["Meta Ads", "Lead Generation", "Content Strategy", "Landing Pages"],
  },
  {
    slug: "agent-sauce",
    company: "Agent Sauce",
    role: "Marketing Intern",
    team: "Freelance Contract",
    period: "Mar — Jun 2023",
    location: "Remote",
    type: "Internship",
    current: false,
    url: "https://agentsauce.com",
    summary: "SEO-driven copy and content strategy for a real estate SaaS brand — landing page rewrites, keyword research, and editorial calendar.",
    skills: ["SEO Copywriting", "SaaS Marketing", "Keyword Research", "Editorial Planning"],
    image: "/agent-sauce.png",
  },
];

function ExperienceCard({ exp, index }: { exp: typeof experiences[0]; index: number }) {
  const [, navigate] = useLocation();
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
          }, index * 120);
        }
      },
      { threshold: 0.08 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={cardRef}
      className="group border-b border-white/6 last:border-b-0 cursor-pointer"
      style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s cubic-bezier(0.25,0.46,0.45,0.94), transform 0.6s cubic-bezier(0.25,0.46,0.45,0.94)" }}
      onClick={() => navigate(`/experience/${exp.slug}`)}
    >
      <div className="py-8 lg:py-10 grid grid-cols-12 gap-4 items-start hover:bg-white/[0.015] transition-colors duration-300 -mx-4 px-4 lg:-mx-6 lg:px-6">

        {/* Left: index */}
        <div className="col-span-1 hidden lg:block">
          <span className="font-mono text-xs text-[#2A2A28] group-hover:text-[#A8A8A0] transition-colors duration-300 mt-0.5 block">
            0{index + 1}
          </span>
        </div>

        {/* Center: info */}
        <div className="col-span-12 lg:col-span-7">
          <div className="flex flex-wrap items-center gap-2 mb-3">
            {exp.current && (
              <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] border border-[#A8A8A0]/20 px-2 py-0.5 tracking-widest uppercase">
                <span className="w-1 h-1 rounded-full bg-[#A8A8A0] dot-pulse" />
                Current
              </span>
            )}
            <span className="font-mono text-[10px] text-[#3A3A38] border border-white/6 px-2 py-0.5 tracking-widest uppercase">
              {exp.type}
            </span>
          </div>
          <h3 className="font-display text-2xl lg:text-3xl font-light text-[#F0EDE8] group-hover:text-white transition-colors duration-300 mb-1">
            {exp.company}
          </h3>
          <p className="font-body text-sm text-[#5A5A55] mb-1">{exp.role}</p>
          <p className="font-body text-sm text-[#4A4A48] leading-relaxed mt-3 max-w-lg">
            {exp.summary}
          </p>
          <div className="flex flex-wrap gap-2 mt-4">
            {exp.skills.map((s) => (
              <span key={s} className="font-mono text-[10px] text-[#3A3A38] border border-white/5 px-2 py-1 tracking-wide uppercase group-hover:border-white/8 transition-colors duration-300">
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* Right: meta + CTA */}
        <div className="col-span-12 lg:col-span-4 lg:flex flex-col items-end justify-between gap-4 hidden">
          <div className="flex flex-col items-end gap-1">
            <span className="font-mono text-xs text-[#3A3A38]">{exp.period}</span>
            <span className="flex items-center gap-1 font-mono text-[10px] text-[#2A2A28]">
              <MapPin size={9} />
              {exp.location}
            </span>
          </div>
          <span className="inline-flex items-center gap-2 font-mono text-[10px] text-[#4A4A48] group-hover:text-[#A8A8A0] tracking-widest uppercase transition-all duration-300">
            Deep Dive
            <ArrowUpRight size={11} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
          </span>
        </div>

        {/* Mobile: meta row */}
        <div className="col-span-12 flex items-center justify-between lg:hidden mt-2">
          <span className="flex items-center gap-1 font-mono text-[10px] text-[#2A2A28]">
            <MapPin size={9} /> {exp.location} · {exp.period}
          </span>
          <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase">
            Deep Dive <ArrowUpRight size={10} />
          </span>
        </div>
      </div>
    </div>
  );
}

export default function ExperienceSection() {
  const headerRef = useRef<HTMLDivElement>(null);
  const featuredRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const elements = [headerRef.current, featuredRef.current].filter(Boolean);
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).style.opacity = "1";
            (entry.target as HTMLElement).style.transform = "translateY(0)";
          }
        });
      },
      { threshold: 0.1 }
    );
    elements.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="experience" className="py-24 lg:py-32 bg-[#0D0D0B] relative">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div
          ref={headerRef}
          className="mb-16"
          style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
        >
          <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block mb-3">
            Work Experience
          </span>
          <h2 className="font-display text-4xl lg:text-5xl font-light text-[#F0EDE8]">
            Where I've Made an Impact
          </h2>
        </div>

        {/* Freedom Mobile featured banner */}
        <div
          ref={featuredRef}
          className="mb-16 overflow-hidden"
          style={{ opacity: 0, transform: "translateY(24px)", transition: "opacity 0.7s ease, transform 0.7s ease" }}
        >
          <div className="relative h-56 lg:h-72 overflow-hidden">
            <img
              src={FREEDOM_IMG}
              alt="Freedom Mobile"
              className="w-full h-full object-cover"
              style={{ objectPosition: "center 40%" }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0D0D0B]/92 via-[#0D0D0B]/55 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0B]/40 to-transparent" />
            <div className="absolute inset-0 flex items-end p-8 lg:p-12">
              <div>
                <span className="font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase block mb-2">
                  Current Role · Internship
                </span>
                <h3 className="font-display text-3xl lg:text-5xl font-light text-white mb-1">
                  Freedom Mobile
                </h3>
                <p className="font-body text-sm text-white/50">
                  Social Media Intern — Advertising &amp; Social
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Summary cards */}
        <div className="border-t border-white/6">
          {experiences.map((exp, i) => (
            <ExperienceCard key={exp.slug} exp={exp} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
