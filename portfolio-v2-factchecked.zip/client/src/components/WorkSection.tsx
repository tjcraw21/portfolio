import { useRef, useEffect, useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { useLocation } from "wouter";

const projects = [
  {
    slug: "mothers-grief-journey",
    index: "01",
    name: "Mothers Grief Journey",
    year: "2025",
    location: "Toronto, ON",
    category: "Brand Strategy",
    summary: "Full brand strategy for a grief support platform centered on healing through storytelling.",
    tags: ["Brand Identity", "Content Strategy", "Audience Development"],
    image: "/mothers-grief.png",
    url: "https://mothersgriefjourney.net",
  },
  {
    slug: "lumiorb",
    index: "02",
    name: "LumiOrb",
    year: "2024",
    location: "Toronto, ON",
    category: "Growth Strategy",
    summary: "Growth strategy for a celestial DTC product launched and grown entirely through short-form content.",
    tags: ["DTC Growth", "Short-Form Content", "Organic Social"],
    image: "/lumiorb.png",
    url: null,
  },
  {
    slug: "shufflemate",
    index: "03",
    name: "Shufflemate",
    year: "2024",
    location: "Toronto, ON",
    category: "Content Production",
    summary: "End-to-end content production and ad copy for a card shuffler brand — game night positioned.",
    tags: ["Content Production", "Ad Copy", "Lifestyle Creative"],
    image: "/shufflemate.png",
    url: "https://shufflemate.com",
  },
];

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [hovered, setHovered] = useState(false);
  const [, navigate] = useLocation();
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => {
            el.style.opacity = "1";
            el.style.transform = "translateY(0)";
          }, index * 120);
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [index]);

  return (
    <div
      ref={cardRef}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group relative border-b border-white/6 last:border-b-0 cursor-pointer"
      style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s cubic-bezier(0.25,0.46,0.45,0.94), transform 0.6s cubic-bezier(0.25,0.46,0.45,0.94)" }}
      onClick={() => navigate(`/work/${project.slug}`)}
    >
      <div className="grid grid-cols-12 gap-4 py-8 lg:py-10 items-start hover:bg-white/[0.015] transition-colors duration-300 -mx-4 px-4 lg:-mx-6 lg:px-6">

        {/* Index */}
        <div className="col-span-2 lg:col-span-1">
          <span className="font-mono text-xs text-[#2A2A28] group-hover:text-[#A8A8A0] transition-colors duration-300">
            {project.index}
          </span>
        </div>

        {/* Info */}
        <div className="col-span-10 lg:col-span-5">
          <h3 className="font-display text-2xl lg:text-3xl font-light text-[#F0EDE8] group-hover:text-white transition-colors duration-300 leading-tight mb-2">
            {project.name}
          </h3>
          <p className="font-body text-sm text-[#4A4A48] leading-relaxed max-w-md group-hover:text-[#5A5A55] transition-colors duration-300">
            {project.summary}
          </p>
          <div className="flex flex-wrap gap-2 mt-4">
            {project.tags.map((tag) => (
              <span
                key={tag}
                className="font-mono text-[10px] text-[#3A3A38] border border-white/5 px-2 py-1 tracking-wide uppercase group-hover:border-white/8 group-hover:text-[#4A4A48] transition-all duration-300"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Year + Category + Location */}
        <div className="hidden lg:flex lg:col-span-2 flex-col gap-1 pt-1">
          <span className="font-mono text-xs text-[#2A2A28] group-hover:text-[#3A3A38] transition-colors duration-300">{project.year}</span>
          <span className="font-body text-xs text-[#3A3A38] group-hover:text-[#4A4A48] transition-colors duration-300">{project.category}</span>
          <span className="font-mono text-[10px] text-[#2A2A28] mt-1">{project.location}</span>
        </div>

        {/* Image + deep dive CTA */}
        <div className="hidden lg:flex lg:col-span-4 flex-col gap-3">
          <div
            className="relative overflow-hidden aspect-[16/9] bg-[#1A1A18]"
            style={{ borderRadius: "2px" }}
          >
            <img
              src={project.image}
              alt={project.name}
              className="w-full h-full object-cover transition-all duration-600"
              style={{
                opacity: hovered ? 1 : 0.3,
                transform: hovered ? "scale(1.04)" : "scale(1)",
              }}
            />
            <div
              className="absolute inset-0 bg-gradient-to-t from-[#0F0F0D]/50 to-transparent transition-opacity duration-300"
              style={{ opacity: hovered ? 0 : 1 }}
            />
          </div>
          <div className="flex items-center justify-end">
            <span className="inline-flex items-center gap-2 font-mono text-[10px] text-[#3A3A38] group-hover:text-[#A8A8A0] tracking-widest uppercase transition-all duration-300">
              Deep Dive
              <ArrowUpRight size={11} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-300" />
            </span>
          </div>
        </div>

        {/* Mobile deep dive */}
        <div className="col-span-12 flex items-center justify-between lg:hidden mt-1">
          <span className="font-mono text-[10px] text-[#2A2A28]">{project.location} · {project.year}</span>
          <span className="inline-flex items-center gap-1.5 font-mono text-[10px] text-[#A8A8A0] tracking-widest uppercase">
            Deep Dive <ArrowUpRight size={10} />
          </span>
        </div>
      </div>
    </div>
  );
}

export default function WorkSection() {
  const headerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.style.opacity = "1";
          el.style.transform = "translateY(0)";
        }
      },
      { threshold: 0.1 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="work" className="py-24 lg:py-32 bg-[#0F0F0D]">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-12">
        <div
          ref={headerRef}
          className="flex items-end justify-between mb-16"
          style={{ opacity: 0, transform: "translateY(20px)", transition: "opacity 0.6s ease, transform 0.6s ease" }}
        >
          <div>
            <span className="font-mono text-xs text-[#A8A8A0] tracking-widest uppercase block mb-3">
              Selected Projects
            </span>
            <h2 className="font-display text-4xl lg:text-5xl font-light text-[#F0EDE8]">
              Work I'm Proud Of
            </h2>
          </div>
          <span className="font-mono text-xs text-[#2A2A28] hidden md:block">
            '23 — Present
          </span>
        </div>

        <div className="border-t border-white/6">
          {projects.map((project, i) => (
            <ProjectCard key={project.slug} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
